using System;
using System.Drawing;
using System.Windows.Forms;

namespace pge_form
{
    public partial class Form1 : Form
    {
        private Panel panelBotonera;
        private Label lblUltimo;
        private int ultimoPiso = 0;   

        public Form1()
        {
            InitializeComponent();

            
            Text = "ascensor";
            MinimumSize = new Size(360, 220);

            panelBotonera = new Panel
            {
                Dock = DockStyle.Top,
                Height = 120,
                BackColor = Color.White
            };
            panelBotonera.Paint += PanelBotonera_Paint;
            panelBotonera.MouseDown += PanelBotonera_MouseDown;
            Controls.Add(panelBotonera);

           
            lblUltimo = new Label
            {
                Dock = DockStyle.Fill,
                Text = "�ltimo piso: �",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(FontFamily.GenericSansSerif, 14, FontStyle.Bold)
            };
            Controls.Add(lblUltimo);
        }

  
        private Rectangle[] CalcularRects()
        {
            int ancho = panelBotonera.ClientSize.Width;
            int margen = 12;
            int cantidad = 3;
            int alto = 80;

            int anchoDisponible = ancho - (margen * (cantidad + 1));
            int anchoRect = anchoDisponible / cantidad;

            Rectangle[] r = new Rectangle[cantidad];
            int y = (panelBotonera.ClientSize.Height - alto) / 2;

            for (int i = 0; i < cantidad; i++)
            {
                int x = margen + i * (anchoRect + margen);
                r[i] = new Rectangle(x, y, anchoRect, alto);
            }
            return r;
        }

  
        private void PanelBotonera_Paint(object sender, PaintEventArgs e)
        {
            var rects = CalcularRects();
            using var pen = new Pen(Color.Black, 2);
            using var font = new Font(FontFamily.GenericSansSerif, 18, FontStyle.Bold);

            for (int i = 0; i < rects.Length; i++)
            {
                bool seleccionado = (ultimoPiso == i + 1);
                using var bg = new SolidBrush(seleccionado ? Color.PaleVioletRed : Color.White);

                e.Graphics.FillRectangle(bg, rects[i]);
                e.Graphics.DrawRectangle(pen, rects[i]);

                TextRenderer.DrawText(
                    e.Graphics,
                    (i + 1).ToString(),
                    font,
                    rects[i],
                    Color.Black,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter
                );
            }
        }

 
        private void PanelBotonera_MouseDown(object sender, MouseEventArgs e)
        {
            var rects = CalcularRects();
            for (int i = 0; i < rects.Length; i++)
            {
                if (rects[i].Contains(e.Location))
                {
                    ultimoPiso = i + 1;
                    lblUltimo.Text = $"ultimo piso: {ultimoPiso}";
                    panelBotonera.Invalidate(); 
                    return;
                }
            }
        }
    }
}
